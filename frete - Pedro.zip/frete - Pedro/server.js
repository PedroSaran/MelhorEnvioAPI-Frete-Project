/* Autor: Pedro Saran
02/23
Cotar-Frete via API */

// Modules const`s
const express = require('express');
const json2csv = require('json-2-csv');
const fs = require('fs');
const path = require('path');
const app = express();
const bodyParser = require('body-parser');

// Express config
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Body-parser config
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

// >> Melhor envio API << //
app.post('/submit', async (req, res) => {
  try {
    var axios = require('axios');
    var data = JSON.stringify({
      "from": {
        "postal_code": req.body.cep_origem
      },
      "to": {
        "postal_code": req.body.cep_destino
      },
      "products": [
        {
          "id": req.body.id_produto,
          "length": req.body.comprimento,
          "width": req.body.largura,
          "height": req.body.altura,
          "weight": req.body.peso,
          "insurance_value": req.body.valor_seguro,
          "quantity": req.body.quantidade
        }
      ]
    });
    
    // API configuration
    var config = {
      method: 'post',
    maxBodyLength: Infinity,
      url: 'https://melhorenvio.com.br/api/v2/me/shipment/calculate',
      headers: { 
        'Accept': 'application/json', 
        'Content-Type': 'application/json',
        //API token
        'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImY1ZTdiNTRlODk1MTIyZDcwMmZkZjEzMWU3MTg2NTkxYjk3YjI1YjYyMjMyZjBjY2JkOGFlY2I3Njg5ZWE5OGI2MDg5NTVjZjdjZjdiM2ZlIn0.eyJhdWQiOiIxIiwianRpIjoiZjVlN2I1NGU4OTUxMjJkNzAyZmRmMTMxZTcxODY1OTFiOTdiMjViNjIyMzJmMGNjYmQ4YWVjYjc2ODllYTk4YjYwODk1NWNmN2NmN2IzZmUiLCJpYXQiOjE2NzcyNjU4NjksIm5iZiI6MTY3NzI2NTg2OSwiZXhwIjoxNzA4ODAxODY5LCJzdWIiOiI2NDQxZmYyMS05ZjhhLTQ2NDktYmNiZS0yMjk1Mjk0OTVjY2YiLCJzY29wZXMiOlsic2hpcHBpbmctY2FsY3VsYXRlIl19.sdJAIPTtq6en8Ef0Y5jdGazKETZmEteQfstiU0QC7S125CvgjZmYPxNveCuKx-yBx_c6XAj1srA_7-KRazpnGZJot6r-CYzFuAEsw4JbBMcC6ziFS9dAh4K4ywkALP0t5GJfYLvpoPNVB1mA7fPFTV1tgrNRK1LlDZM8eYL8dJrcVqMm2yHL5TzTv5ahDXUwk2l91eWExUcRMJiQbwqpbSDva85yDq3k_HWQTQEKZniNl_1y9G6pzMieSL_VMV4W1ofxr5Ukc7rSj-2V856QezFYPLScHRPl1zNjz8-MQtubxuz9yNCfkerxCjSP63xcpC8a4PQKUUPYaALEvix9oBoEpM3L3Nm_n-yAXGmfMZJ0MzDRK2ejwWIb2g9L2jEES50FxTKtxjG5m7oZ6sTlNf95Zx65jZ-xZBrifYMop3Hxa47I5zLBqHojektGtNH4RgJM6WTMMv_a_EeIlN_XKQUIonNtQNAPo-tHVDQsY-q1_qyIOqloi-4jM2T2Y4G0qgX48wPNsYyHA5HB4Mth0vEnfgFJJ2BeDCscEqgrXK-28SI5-22mF7TvOBOyYoVuk5ZFhJN4L0zhNTjUHHuVDc7l6vuqLhASC3MAjwBYe972u5UGaeAY0IIlzCwSG__ND5UvcQk2sZVJLE47MIWNG-3FAcxWOkVTw9bZ_ssT-QM', 
        'User-Agent': 'Aplicação (email para contato técnico)'
      },
      data : data
    };

    // Get API results, stringfy method
    const response = await axios.post('https://melhorenvio.com.br/api/v2/me/shipment/calculate', data, config);
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })

    // If error
    .catch(function (error) {
      console.log(error);
    });
   
    // Convert the response data to CSV format
    const csvData = await json2csv.json2csvAsync(response.data);

    // Save the CSV file to the server
    const filePath = path.join(__dirname, 'results.csv');
    fs.writeFileSync(filePath, csvData);

    // Send a response back to the client
    res.send('Arquivo Salvo Com Sucesso!');
  } catch (error) {
      console.error(error);
      res.status(500).send('Server error');
    }
});

// console.log to say, Server is online
// localhost:3000
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server online on port ${PORT}`);
});